# Foundation 6 Developer Shopify Theme

There aren't many Shopify themes using Foundation as the CSS framework. Let's change that, shall we?


# Demo

http://foundation-6-boilerplate.myshopify.com/